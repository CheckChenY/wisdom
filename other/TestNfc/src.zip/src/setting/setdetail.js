import React , { Component } from 'react';
import {Text,View} from 'react-native';


class SetDetail extends Component{
    render(){
        return(
            <View>
                <Text>
                    我是set二级页面
                </Text>
            </View>
        )
    }
}

export default SetDetail