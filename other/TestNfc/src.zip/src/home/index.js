import React , { Component } from 'react';
import {Text,View} from 'react-native';


class HomeDetail extends Component{
    render(){
        return(
            <View>
                <Text>
                    我是home二级页面
                </Text>
            </View>
        )
    }
}

export default HomeDetail
