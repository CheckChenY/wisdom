import React , { Component } from 'react';
import {Text,View} from 'react-native';


class MainDetail extends Component{
    render(){
        return(
            <View>
                <Text>
                    我是main二级页面
                </Text>
            </View>
        )
    }
}

export default MainDetail